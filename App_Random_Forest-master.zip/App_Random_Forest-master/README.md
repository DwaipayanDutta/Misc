App_Random_Forest
=================
Developing End to End Random Forest Model.

To do:
1. Add other plots
  - Partial dependance plots
  - Accuracy based on ntree(number of trees)
  - Other
2. Add Upload button in the simulator.
3. Aesthic Improvements.

Major Improvements:
1. Add Regression Model.
2. Add Notes & How to do Video.
3. Add About Tab & License.
